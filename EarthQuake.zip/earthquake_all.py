#import re - get_quake関数で、正規表現する際使用
#import shutil - 最後にextract_data.txtの内容をlast_data.txtにコピーする際使用
#import requests - get_quake関数で、情報元のhtmlを読み込む際に使用
#from bs4 import BeautifulSoup - get_quake関数で、情報を割り出す際に使用
#import hashlib - retrieve_extracted_data関数でハッシュ値出す際に使用

import re
import shutil
import requests
from bs4 import BeautifulSoup
import hashlib
import tweepy
from time import sleep
import datetime

datetime = datetime.datetime.now()
month = datetime.month
day = datetime.day
hour = datetime.hour
minute = datetime.minute
Extracted_data = "/xxxxxxxxxx/extracted_data.txt"
Last_data = "/xxxxxxxxxx/last_data.txt"
inv1 = "/xxxxxxxxxx/extracted_data"
inv2 = str(month) + str(day) + str(hour) + str(minute)
Inv_data = inv1 + inv2 + ".txt"
CONSUMER_KEY = 'xxxxxxxxxx'
CONSUMER_SECRET = 'xxxxxxxxxx'
ACCESS_KEY = 'xxxxxxxxxx'
ACCESS_SECRET = 'xxxxxxxxxx'
auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_KEY, ACCESS_SECRET)
api = tweepy.API(auth)

def get_quake(path):
    html = requests.get("https://earthquake.tenki.jp/bousai/earthquake/")
    soup = BeautifulSoup(html.text,"html.parser")
    earthquake_datetime = "地震発生時刻⇒ "
    earthquake_place = "震源地⇒ "
    place_info1 = "/bousai/earthquake/center/"
    place_info2 = r"\d\d\d/"
    place_info3 = place_info1 + place_info2
    earthquake_place_info = re.compile(place_info3)
    earthquake_intensity = "最大震度⇒ "
    ex_datetime = ""
    ex_place = ""
    ex_intensity = ""
    newline = "\n"
    space = " "
    hash_tag1 = "#earthquake #jishin #地震"
    ex_intensity3 = "震度3"
    ex_intensity4 = "震度4"
    ex_intensity5 = "震度5"
    ex_intensity6 = "震度6"

    #地震発生時刻を抽出
    infotable = soup.find_all("td", attrs={"id": "earthquake-generating-datetime"})
    body = [e.text for e in infotable]
    ex_datetime = (body.pop(0))

    #pathに保存
    with open(path, "w") as f:
        f.write("".join(earthquake_datetime))
        f.write("".join(ex_datetime))

    #震度を抽出
    infotable2 = soup.find_all("h3", attrs={"class": "earthquake-sindo-index"})
    body2 = [e.text for e in infotable2]
    ex_intensity = (body2.pop(0))

    #震源地を抽出
    if ex_intensity == ex_intensity3 or ex_intensity == ex_intensity4 or ex_intensity == ex_intensity5 or ex_intensity == ex_intensity6:
        sleep(10)
    infotable3 = soup.find_all("a", attrs={"class": "text-link", "href": earthquake_place_info})
    body3 = [e.text for e in infotable3]
    ex_place = (body3.pop(0))

    #pathに保存
    with open(path, "a") as f:
        f.write("".join(newline))
        f.write("".join(earthquake_place))
        f.write("".join(ex_place))

    #hash_tag2とhash_tag3を生成
    hash_tag2 = ("#" + str(ex_place))
    hash_tag3 = ("#" + str(ex_intensity))

    #pathに保存
    with open(path, "a") as f:
        f.write("".join(newline))
        f.write("".join(earthquake_intensity))
        f.write("".join(ex_intensity))
        f.write("".join(newline))
        f.write("".join(hash_tag1))
        f.write("".join(space))
        f.write("".join(hash_tag2))
        f.write("".join(space))
        f.write("".join(hash_tag3))
        f.write("".join(newline))

def retrieve_extracted_data(Extracted_data):
     with open(Extracted_data, 'r') as f_read:
         extracted_data = str(f_read.read().strip())
         return extracted_data

def compare_extracted_last():
     with open(Extracted_data,'rb') as Openfile1:
         BinaryData1 = Openfile1.read()

     with open(Last_data,'rb') as Openfile2:
         BinaryData2 = Openfile2.read()

     Extracted_data_MD5 = hashlib.md5(BinaryData1).hexdigest()
     Last_data_MD5 = hashlib.md5(BinaryData2).hexdigest()

     if(Extracted_data_MD5==Last_data_MD5):
         Comp_result ="same"
         return Comp_result

     elif(Extracted_data_MD5!=Last_data_MD5):
         Comp_result =""
         Comp_result = retrieve_extracted_data(Extracted_data)
         return Comp_result

#body - Extracted_dataに地震情報の最新情報を保存
#Body_message - Extracted_dataがLast_dataと同じの場合にsame、それ以外は最新情報>出力
body = get_quake(Extracted_data)
Body_message = compare_extracted_last()

if(Body_message=="same"):
    pass

elif(Body_message!="same"):
   api.update_status(Body_message)
   shutil.copyfile(Extracted_data, Last_data)
   shutil.copyfile(Extracted_data, Inv_data)
